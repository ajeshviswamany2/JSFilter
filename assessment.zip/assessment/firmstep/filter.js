var Manufacturer = [];
var Storage = [];
var OS = [];
var Camera = [];
var Phones = {};

function fetchJSONFile(path, callback) {
    var httpRequest = new XMLHttpRequest();
    httpRequest.onreadystatechange = function() {
        if (httpRequest.readyState === 4) {
            if (httpRequest.status === 200) {
                var data = JSON.parse(httpRequest.responseText);
                if (callback) callback(data);
            }
        }
    };
    httpRequest.open('GET', path);
    httpRequest.send();
}

function buildList(data) {
    $.each(data, function(i, item) {
        var newPhone = '<li>' +
            '<a href="#" class="product-photo">' +
            '<img src="' + item.image.small + '" height="130" alt="Iphone 6">' +
            '</a>' +
            '<h2><a href="#">' + item.name + '</a></h2>' +
            '<ul class="product-description">' +
            '<li><span>Manufacturer: </span>' + item.specs.manufacturer + '</li>' +
            '<li><span>Storage: </span>' + item.specs.storage + ' GB</li>' +
            '<li><span>OS: </span>' + item.specs.os + '</li>' +
            '<li><span>Camera: </span>' + item.specs.camera + ' Mpx</li>' +
            '<li><span>Description: </span>' + item.description + '</li>' +
            '</ul>' +
            '<p class="product-price">£' + item.price + '</p>' +
            '</li>';
        $(".products-list").append(newPhone);
    });
}

function filterManufacturer(item) {
    for (var i = 0; Manufacturer.length > i; i++) {
        if (item.specs.manufacturer == Manufacturer[i]) {
            return true;
			}
    }
}

function filterStorage(item) {
    for (var i = 0; Storage.length > i; i++) {
        if (item.specs.storage == Storage[i]) {
            return true;
        }
    }
}

function filterOS(item) {
    for (var i = 0; OS.length > i; i++) {
        if (item.specs.os == OS[i]) {
            return true;
        }
    }
}

function filterCamera(item) {
    for (var i = 0; Camera.length > i; i++) {
        if (item.specs.camera == Camera[i]) {
            return true;
        }
    }
}

function filter() {
    debugger;
    $(document).ready(function() {
        Manufacturer = [];
        Storage = [];
        OS = [];
        Camera = [];
		$('#products-list').empty();

        if (document.querySelectorAll("input[name='Manufacturer']:checked").length > 0) {
            $.each($("input[name='Manufacturer']:checked"), function() {

                Manufacturer.push($(this).val());
            });
        }
        if (document.querySelectorAll("input[name='Storage']:checked").length > 0) {
            $.each($("input[name='Storage']:checked"), function() {

                Storage.push($(this).val());
            });
        }
        if (document.querySelectorAll("input[name='OS']:checked").length > 0) {
            $.each($("input[name='OS']:checked"), function() {

                OS.push($(this).val());
            });
        }
        if (document.querySelectorAll("input[name='Camera']:checked").length > 0) {
            $.each($("input[name='Camera']:checked"), function() {

                Camera.push($(this).val());
            });
        }
  fetchJSONFile('products.json', function(data) {
            // do something with your data
			Phones=data;
			if(Manufacturer.length>0){
            Phones = data.filter(filterManufacturer);
			}
			if(Storage.length>0){
            Phones = Phones.filter(filterStorage);
			}
			if(OS.length>0){
            Phones = Phones.filter(filterOS);
			}
			if(Camera.length>0){
            Phones = Phones.filter(filterCamera);
			}
            buildList(Phones);

        });
       
    });
}

function clearFilter(){
	$(document).ready(function() {
	$('#products-list').empty();
	 $('input:checkbox').removeAttr('checked');
	 filter();
	  });
	 
}